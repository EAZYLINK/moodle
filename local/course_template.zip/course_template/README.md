# moodle-local_course_templates
With this moodle plugin you can easily create courses based on course templates. The plugin also can be used to easily duplicate courses.
